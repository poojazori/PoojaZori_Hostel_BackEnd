package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Hostel;

public interface HostelRepository extends JpaRepository<Hostel, Integer>{

}

package com.service;

import com.model.Floor;

public interface FloorService {

	Floor addFloor(Floor floor);

}

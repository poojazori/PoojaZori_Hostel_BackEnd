package com.service;

public interface RoleService {

}
